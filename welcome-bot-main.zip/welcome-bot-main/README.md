# welcome-bot
Discord Welcome botu altyapısıdır | Fırat Öner Youtube kanalına aittir.

➥ GHOST DEV: https://bit.ly/3s18fx8 
➥ GHOST Botlist: Yakında...

➥ Kanalıma ücretsiz bir şekilde abone olmak için: https://bit.ly/3rVJ6nT
