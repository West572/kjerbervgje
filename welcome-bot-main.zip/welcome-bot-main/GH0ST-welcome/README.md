# discord-welcome-bot

A great intro sounds for Discord servers!

# Setup the Project

1. Download or clone this project.
2. Setup the project options from `config.json` file.
3. Upload the required audio files in `default_files` path and enter audio files name in `config.json`.
4. Run `app.js` file from terminal. (Example run command: `node app.js`)

**(!) DO NOT FORGET** You must install **FFMPEG** on your system to run.

# Information

**(!)** If there is something that can be added to this project or if you have found anything missing in this project, you can let us know and help us improve the project! [Let us know!](https://github.com/polemikal/discord-slash-commands-bot/issues)

**(!)** This project is shared on behalf of [Serendia Squad](https://discord.com/invite/serendia). If you need any help about this project, you can join this platform and ask questions in your mind.




